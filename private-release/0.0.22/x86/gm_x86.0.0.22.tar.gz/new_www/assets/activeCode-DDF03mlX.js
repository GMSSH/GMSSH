var r=(a=>(a[a.NO_ACTIVE=0]="NO_ACTIVE",a[a.ACTIVE=1]="ACTIVE",a[a.EXPIRED=2]="EXPIRED",a))(r||{});const I=30;export{r as A,I as a};
