const e="/newweb/static/images/folder.png";export{e as f};
